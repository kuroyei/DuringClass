#include <iostream>
using namespace std;

class Car
{
    private:
        int num; double gas;
    public:
        Car();
        Car(int n, double g);
        void show();
};

Car::Car()
{
    num = 0;
    gas = 0.0;
    cout << "Created a car." << endl;
}
Car::Car(int n, double g)
{
    num = n;
    gas = g;
    cout << "Number: " << num << ", Gas: " << gas << " car created." << endl;
}
void Car::show()
{
    cout << "Number of car is " << num << '.' << endl;
    cout << "Amount of gas is " << gas << '.' << endl;
}

int main()
{
    Car mycars[3];

    return 0;
}