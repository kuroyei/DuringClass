#include <iostream>
using namespace std;

class Car
{
    private:
        int num;
        double gas;
    public:
        Car();
        void show();
};

Car::Car()
{
    num = 0;
    gas = 0.0;
    cout << "Created a car." << endl;
}
void Car::show()
{
    cout << "Number of car is " << num << '.' << endl;
    cout << "Amount of gas is " << gas << '.' << endl;
}

int main()
{
    Car car1; // ここでCar()が呼び出される
    car1.show();

    return 0;
}