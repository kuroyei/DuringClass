#include <iostream>
using namespace std;

class Car
{
    private:
        int num; double gas;
    public:
        Car();
        Car(int n, double g);
        void setCar(int n, double g);
        void show();
};

class RacingCar : public Car
{
    private:
        int course;
    public:
        RacingCar();
        RacingCar(int n, double g, int c);
        void setCourse(int c);
};

Car::Car()
{
    //
        cout << "<!-- Car::Car() -->" << endl;
    num = 0;
    gas = 0.0;
    cout << "Created a car." << endl;
}
Car::Car(int n, double g)
{
    //
        cout << "<!-- Car::Car(int n, double g) -->" << endl;
    num = n;
    gas = g;
    cout << "A car Number: " << num << ", gas: " << gas << " created." << endl;
}
void Car::setCar(int n, double g)
{
    // 
        cout << "<!-- Car::setCar(int n, double g) -->" << endl;
    num = n;
    gas = g;
    cout << "Set Number: " << num << ", Gas: " << gas << '.' << endl;
}
void Car::show()
{
    // 
        cout << "<!-- Car::show() -->" << endl;
    cout << "Number of car is " << num << '.' << endl;
    cout << "Amount of gas is " << gas << '.' << endl;
}

RacingCar::RacingCar()
{
    //
        cout << "<!-- RacingCar::RacingCar() -->" << endl;
    course = 0;
    cout << "Created a racing car." << endl;
}
RacingCar::RacingCar(int n, double g, int c) : Car(n,g)
{
    //
        cout << "<!-- RacingCar::RacingCar(int n, double g, int c) : Car(n,g) -->" << endl;
    course = c;
    cout << "Created a racing car course: " << c << '.' << endl;
}
void RacingCar::setCourse(int c)
{
    // 
        cout << "<!-- RacingCar::setCourse(int c) -->" << endl;
    course = c;
    cout << "Set course nubmer " << c << endl;
}

int main()
{
    RacingCar rccar1(1234,20.5,5);

    return 0;
}
